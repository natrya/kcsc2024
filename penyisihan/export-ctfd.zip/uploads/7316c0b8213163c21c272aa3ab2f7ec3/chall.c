#include <stdio.h>
#include <stdlib.h>

#define MAX_FILE_NAME_LENGTH 256
#define MAX_BUFFER_LENGTH 1024

void init(){
        setvbuf(stdin,0,2,0);
        setvbuf(stdout,0,2,0);
}


int main() {
    init();

    char file_name[MAX_FILE_NAME_LENGTH];
    char buffer[MAX_BUFFER_LENGTH];
    FILE *fp;
    size_t bytes_read;

    printf("Masukkan nama file kamu: ");
    scanf("%s", file_name);

    // Membuat string command untuk membaca file
    char command[MAX_FILE_NAME_LENGTH + 10];
    snprintf(command, sizeof(command), "cat %s", file_name);

    // Membuka file dan membaca isinya
    fp = popen(command, "r");
    if (fp == NULL) {
        printf("Gagal membuka file.\n");
        exit(1);
    }

    bytes_read = fread(buffer, 1, MAX_BUFFER_LENGTH, fp);
    printf("Isi file:\n%s\n", buffer);

    pclose(fp);
    return 0;
}
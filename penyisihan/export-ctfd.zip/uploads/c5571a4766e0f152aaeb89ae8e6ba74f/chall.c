#include<stdio.h>

void hacked()
{
    printf("Selamat anda sudah didalam server\n");
    system("/bin/sh");
}

void awal()
{
    char buffer[60];
    puts("Input namamu :\n");
    gets(buffer);
}

void main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    awal();
}

#include<stdio.h>

void foo()
{
    char buffer[40];
    puts("give me your input :)\n");
    gets(buffer);
}

void main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    foo();
}

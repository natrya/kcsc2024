#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

void win() {
    // Buka file flag.txt untuk dibaca
    FILE *flag_file;
    char flag[100];  // Buffer untuk menyimpan isi file flag.txt

    flag_file = fopen("flag.txt", "r");  // Buka file flag.txt dalam mode read (r)
    
    if (flag_file == NULL) {
        printf("Tidak dapat membuka file flag.txt!\n");
        return;
    }

    // Baca isi file ke dalam buffer dan cetak ke layar
    fgets(flag, sizeof(flag), flag_file);
    printf("FLAG: %s\n", flag);

    // Tutup file setelah selesai
    fclose(flag_file);
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    int a, b;
    int result;

    printf("Masukkan angka pertama: ");
    scanf("%d", &a);

    printf("Masukkan angka kedua: ");
    scanf("%d", &b);

    // Hitung jumlahnya
    result = a + b;

    printf("Hasil penjumlahan: %d\n", result);

    // Jika result negatif, panggil fungsi win()
    if (result < 0) {
        win();
    } else {
        printf("Tidak ada FLAG untukmu!\n");
    }

    return 0;
}

